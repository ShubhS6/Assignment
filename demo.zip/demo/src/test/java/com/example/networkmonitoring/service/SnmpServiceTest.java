package com.example.networkmonitoring.service;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.snmp4j.*;
import org.snmp4j.event.ResponseEvent;
import org.snmp4j.mp.SnmpConstants;
import org.snmp4j.smi.*;
import org.snmp4j.transport.DefaultUdpTransportMapping;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;

class SnmpServiceTest {

    private SnmpService snmpService;
    private Snmp snmp;
    @BeforeEach
    void setUp() throws Exception {
        snmp = Mockito.mock(Snmp.class);
        snmpService = new SnmpService() {
            
            protected Snmp createSnmpInstance() throws Exception {
                return snmp;
            }
        };
    }

    @Test
    void testGetAsString() throws Exception {
        // Setup mock response
        PDU responsePDU = new PDU();
        responsePDU.add(new VariableBinding(new OID("1.3.6.1.2.1.1.5.0"), new OctetString("Test Device")));
        ResponseEvent responseEvent = new ResponseEvent(
                this,
                null,
                responsePDU,
                null,
                false,
                null
        );
        Mockito.when(snmp.send(Mockito.any(PDU.class), Mockito.any(Target.class)))
        .thenReturn(responseEvent);

// Call method
String result = snmpService.getAsString("1.3.6.1.2.1.1.5.0", "127.0.0.1", "public");

// Verify result
assertEquals("Test Device", result);
}
    @Test
    void testGetAsStringTimeout() throws Exception {
        // Setup mock response with null to simulate timeout
        ResponseEvent responseEvent = new ResponseEvent(
                this,
                null,
                null,
                null,
                true,
                null
        );
        Mockito.when(snmp.send(Mockito.any(PDU.class), Mockito.any(Target.class)))
        .thenReturn(responseEvent);

// Call method and expect exception
Exception exception = assertThrows(Exception.class, () -> {
    snmpService.getAsString("1.3.6.1.2.1.1.5.0", "127.0.0.1", "public");
});

// Verify exception message
assertEquals("Timeout or no response received", exception.getMessage());
}
}

