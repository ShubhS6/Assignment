package com.example.networkmonitoring.service;

import org.snmp4j.CommunityTarget;
import org.snmp4j.PDU;
import org.snmp4j.Snmp;
import org.snmp4j.event.ResponseEvent;
import org.snmp4j.mp.SnmpConstants;
import org.snmp4j.smi.*;
import org.snmp4j.transport.DefaultUdpTransportMapping;
import org.springframework.stereotype.Service;

@Service
public class SnmpService {

    private Snmp snmp;

    public SnmpService() throws Exception {
        snmp = new Snmp(new DefaultUdpTransportMapping());
        snmp.listen();
    }

    public String getAsString(String oid, String ipAddress, String community) throws Exception {
        Address targetAddress = GenericAddress.parse("udp:" + ipAddress + "/161");
        CommunityTarget target = new CommunityTarget();
        target.setCommunity(new OctetString(community));
        target.setAddress(targetAddress);
        target.setRetries(2);
        target.setTimeout(1500);
        target.setVersion(SnmpConstants.version2c);

        PDU pdu = new PDU();
        pdu.add(new VariableBinding(new OID(oid)));
        pdu.setType(PDU.GET);

        ResponseEvent response = snmp.send(pdu, target);
        if (response.getResponse() == null) {
            throw new Exception("Timeout or no response received");
        }
        return response.getResponse().get(0).getVariable().toString();
    }

    public String getMemoryUsage(String ipAddress, String community) throws Exception {
        String oid = "1.3.6.1.4.1.2021.4.6.0"; // Example OID for memory usage
        return getAsString(oid, ipAddress, community);
    }

    public String getUptime(String ipAddress, String community) throws Exception {
        String oid = "1.3.6.1.2.1.1.3.0"; // OID for system uptime
        return getAsString(oid, ipAddress, community);
    }
}
