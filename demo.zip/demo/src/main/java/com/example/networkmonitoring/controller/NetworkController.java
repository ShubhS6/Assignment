package com.example.networkmonitoring.controller;

import com.example.networkmonitoring.model.Device;
import com.example.networkmonitoring.service.SnmpService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.ArrayList;
import java.util.List;

@Controller
public class NetworkController {

    @Autowired
    public SnmpService snmpService;

    @GetMapping("/")
    public String home(Model model) {
        List<Device> devices = new ArrayList<>();
        devices.add(new Device("Device1", "25%", "40%", "10 days", "Online"));
        devices.add(new Device("Device2", "35%", "50%", "5 days", "Online"));
        devices.add(new Device("Device3", "15%", "30%", "3 days", "Offline"));
        
        model.addAttribute("devices", devices);
        return "index";
    }

    @PostMapping("/fetchMetrics")
    public String fetchMetrics(@RequestParam String ipAddress, @RequestParam String community, @RequestParam String oid, Model model) {
        try {
            String cpuUsage = snmpService.getAsString(oid, ipAddress, community);
            String memoryUsage = snmpService.getMemoryUsage(ipAddress, community);
            String uptime = snmpService.getUptime(ipAddress, community);

            Device device = new Device(ipAddress, cpuUsage, memoryUsage, uptime, "Online");
            List<Device> devices = new ArrayList<>();
            devices.add(device);

            model.addAttribute("cpuUsage", cpuUsage);
            model.addAttribute("memoryUsage", memoryUsage);
            model.addAttribute("uptime", uptime);
            model.addAttribute("devices", devices);
        } catch (Exception e) {
            model.addAttribute("cpuUsage", "Error: " + e.getMessage());
        }
        return "index";
    }
}
