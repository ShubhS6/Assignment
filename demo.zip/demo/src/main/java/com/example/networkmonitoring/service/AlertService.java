package com.example.networkmonitoring.service;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.stereotype.Service;

@Service
public class AlertService {

    @Autowired
    public JavaMailSender mailSender;

    @Value("${alert.email.recipient}")
    public String recipientEmail;

    @Value("${alert.threshold.cpu}")
    public double cpuThreshold;

    public void checkThreshold(String metric, double value) {
        if (metric.equals("CPU Usage") && value > cpuThreshold) {
            sendAlert(metric, value);
        }
    }

    private void sendAlert(String metric, double value) {
        String subject = "Alert: " + metric + " Threshold Exceeded";
        String text = "The " + metric + " has exceeded the threshold. Current value: " + value;

        SimpleMailMessage message = new SimpleMailMessage();
        message.setTo(recipientEmail);
        message.setSubject(subject);
        message.setText(text);

        mailSender.send(message);

        System.out.println("Alert sent: " + subject + " - " + text);
    }
}
